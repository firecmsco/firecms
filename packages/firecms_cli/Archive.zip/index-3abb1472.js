import { importShared } from './__federation_fn_import.js';
import { j as jsxRuntimeExports } from './jsx-runtime-707d998e.js';
import { r as reactDomExports } from './__federation_shared_react-dom-11692bda.js';
import { config } from './__federation_expose_Config-83a04a08.js';

var client = {};

var m = reactDomExports;
{
  client.createRoot = m.createRoot;
  client.hydrateRoot = m.hydrateRoot;
}

const {FireCMS3App} = await importShared('@firecms/firebase_firecms_v3');
function App() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    FireCMS3App,
    {
      projectId: "firecms-demo-27150",
      signInOptions: [
        "password",
        "google.com"
        // 'anonymous',
        // 'phone',
        // 'facebook.com',
        // 'github.com',
        // 'twitter.com',
        // 'microsoft.com',
        // 'apple.com'
      ],
      config
    }
  );
}

const index = '';

const React = await importShared('react');
client.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(App, {}) })
);
